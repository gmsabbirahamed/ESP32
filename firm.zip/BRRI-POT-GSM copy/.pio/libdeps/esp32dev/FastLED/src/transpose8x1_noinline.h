/// @file transpose8x1_noinline.h
/// Declares the 8x1 transposition function

#pragma once
void transpose8x1_noinline(unsigned char *A, unsigned char *B);
