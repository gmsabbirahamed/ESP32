
// This code is designed to run on an ESP32 device with a SIM7600 GSM module.
#define TINY_GSM_MODEM_SIM7600
#define TINY_GSM_USE_GPRS true
#define TINY_GSM_USE_WIFI false
#define USE_SD_CARD false

//Libraries required for GSM, MQTT, and ESP-NOW functionality
#include <Arduino.h>
#include <TinyGsmClient.h>
#include <PubSubClient.h>
#include <HardwareSerial.h>
#include <deque>
#include <algorithm>
#include <freertos/FreeRTOS.h>
#include <FastLED.h>

// #define DEBUG_MODE true
// #define DEBUG_PRINT(x)  if (DEBUG_MODE) { Serial.print(x); }
// #define DEBUG_PRINTF(x)  if (DEBUG_MODE) { Serial.printf(x); }
// #define DEBUG_PRINTLN(x) if (DEBUG_MODE) { Serial.println(x); }

//Gateway configuration
const char* DEVICE_ID = "1101002409120002";
const char* Local_ID = "gw0"; // Gateway ID

//Timers for publishing data and heartbeat
unsigned long lastDataPublishTime = 0;
const unsigned long dataPublishInterval = 5 * 60 * 1000;

unsigned long lastHBPublishTime = 0;
const unsigned long hbPublishInterval = 2 * 60 * 1000;

unsigned long lastHourCheck = 0;
bool snapshotSentThisHour = false;

//FastLED library for controlling LEDs
#define LED_PIN 4
#define NUM_LEDS 1
CRGB leds[NUM_LEDS];
#define AC_LINE_PIN 34

// GSM settings
#define SerialAT Serial1
#define MODEM_TX 17
#define MODEM_RX 16
#define MODEM_PWR 15
#define SIM_BAUD 115200

const char apn[] = "blweb";
const char user[] = "";
const char pass[] = "";
const char* broker = "broker.hivemq.com";
const char* mqttUser = "";
const char* mqttPass = "";
bool gsmConnected = false;

// MQTT settings
char mqttSubTopic[64]; 
#define MQTT_PORT 1883
#define MQTT_HB "SABBIR/HB"
#define MQTT_PUB "SABBIR/PUB"
#define MQTT_SUB "SABBIR/SUB"
#define MQTT_ACK "SABBIR/ACK"
#define MQTT_TMP "SABBIR/TEMP"



//Struct to hold message data
#define MAX_MQTT_MSG_LEN 128
#define MAX_TOPIC_LEN    64

typedef struct {
    char topic[MAX_TOPIC_LEN];
    char payload[MAX_MQTT_MSG_LEN];
} MqttMessage;


std::deque<String> recentMsgKeys;
const size_t maxRecentIDs = 20;