#define TINY_GSM_MODEM_SIM7600
#include <Arduino.h>
#include <TinyGsmClient.h>
#include <PubSubClient.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <freertos/semphr.h>
#include <esp_task_wdt.h>

// =============== Hardware Configuration ===============
#define SIM_RX 16         // UART2 RX
#define SIM_TX 17         // UART2 TX
#define ONE_WIRE_BUS 19   // DS18B20
#define GSM_PWRKEY_PIN 15 // SIM7600 power key
#define STATUS_LED_PIN 2  // Status LED

// Analog Pins
#define ANALOG_PIN_1 34
#define ANALOG_PIN_2 35
#define ANALOG_PIN_3 36
#define ANALOG_PIN_4 39

// =============== Timing Configuration ===============
#define SENSOR_INTERVAL_MS (5 * 60 * 1000)    // 5 minutes
#define HEARTBEAT_INTERVAL_MS (1 * 60 * 1000) // 1 minute
#define NETWORK_RETRY_DELAY_MS 20000          // 20 seconds
#define MQTT_RECONNECT_DELAY_MS 10000         // 10 seconds

// =============== GSM Configuration ===============
const char apn[] = "blweb";
const char gprsUser[] = "";
const char gprsPass[] = "";
#define GSM_POWER_ON_TIME 2000     // 2 second power key press
#define GSM_POWER_OFF_TIME 3000    // 3 second power key press
#define GSM_STARTUP_DELAY 15000    // 15 seconds after power on
#define GSM_MIN_OPERATING_VOLTAGE 3.6

// =============== Watchdog Configuration ===============
#define HW_WDT_TIMEOUT_S 20        // Hardware WDT timeout
#define TASK_WDT_TIMEOUT_MS 180000 // 3 minutes
#define HEALTH_WDT_TIMEOUT_MS 300000 // 5 minutes
#define WDT_CHECK_INTERVAL_MS 15000  // 15 seconds
#define MEMORY_CRITICAL_THRESHOLD 10000 // 10KB

// =============== MQTT Configuration ===============
const char* mqttBroker            = "broker.hivemq.com";
const int mqttPort                = 1883;
const char* mqttUser              = "";
const char* mqttPassword          = "";
const char* mqttTopic             = "sabbir/sensor/data";
const char* heartbeatTopic        = "sabbir/device/heartbeat";
const char* statusTopic           = "sabbir/device/status";

// =============== Global Objects ===============
TinyGsm modem(Serial1);
TinyGsmClient gsmClient(modem);
PubSubClient mqttClient(gsmClient);
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature ds18b20(&oneWire);

// =============== FreeRTOS Handles ===============
TaskHandle_t networkTaskHandle = NULL;
TaskHandle_t mainTaskHandle = NULL;
TaskHandle_t sensorTaskHandle = NULL;
TaskHandle_t watchdogTaskHandle = NULL;
QueueHandle_t sensorDataQueue = NULL;
SemaphoreHandle_t mqttMutex = NULL;

// =============== Data Structures ===============
typedef struct {
    float temperature;
    int analog1;
    int analog2;
    int analog3;
    int analog4;
    unsigned long timestamp;
    float batteryVoltage;
} SensorData;

typedef struct {
    int heapFree;
    int heapMin;
    int uptimeMinutes;
    int networkStatus;
    int mqttStatus;
    int modemRestarts;
    float supplyVoltage;
    int rssi;
} SystemStatus;

enum NetworkState {
    NETWORK_DISCONNECTED,
    NETWORK_CONNECTING,
    NETWORK_CONNECTED,
    NETWORK_FAILED
};

// =============== Global Variables ===============
volatile NetworkState networkState = NETWORK_DISCONNECTED;
volatile bool mqttConnected = false;
volatile unsigned long networkTaskHeartbeat = 0;
volatile unsigned long mainTaskHeartbeat = 0;
volatile unsigned long sensorTaskHeartbeat = 0;
volatile unsigned long lastSuccessfulMqtt = 0;
volatile unsigned long lastModemRestart = 0;
unsigned long lastReconnectAttempt = 0;
int modemRestartCount = 0;

// =============== Function Prototypes ===============
void initializeHardware();
bool initializeModem();
bool checkModemResponse();
bool connectToNetwork();
bool connectToMQTT();
bool publishSensorData(const SensorData& data);
void publishHeartbeat(const SystemStatus& status);
void publishSystemEvent(const char* message);
SensorData readSensors();
SystemStatus getSystemStatus();
void gsmPowerOn();
void gsmPowerOff();
void emergencyPowerCycle();
void restartNetworkComponents();
void emergencyReset();
float readBatteryVoltage();
void blinkStatusLED(int count);
bool sendSingleMessage(const SensorData& data);
void waitNonBlocking(unsigned long ms);
void hardRSTmodem();



void emergencySleep();
void processMQTT();
void handleGprsRecovery(int* retryCount, int maxRetries);
void handleNetworkRecovery(int* retryCount, int maxRetries);
unsigned long getRetryDelay(int attempt);





// =============== Task Functions ===============
void networkTask(void *pvParameters);
void mainTask(void *pvParameters);
void sensorTask(void *pvParameters);
void watchdogTask(void *pvParameters);

// =============== Setup ===============
void setup() {
    Serial.begin(115200);
    delay(1000);
    
    pinMode(STATUS_LED_PIN, OUTPUT);
    blinkStatusLED(3); // Visual confirmation
    
    initializeHardware();
    
    // if (!initializeModem()) {
    //     Serial.println("Critical: Modem initialization failed!");
    //     emergencyReset();
    // }
    
    // Create FreeRTOS objects with error checking
    mqttMutex = xSemaphoreCreateMutex();
    if (mqttMutex == NULL) {
        Serial.println("Error creating MQTT mutex!");
        emergencyReset();
    }
    
    sensorDataQueue = xQueueCreate(5, sizeof(SensorData));
    if (sensorDataQueue == NULL) {
        Serial.println("Error creating sensor queue!");
        emergencyReset();
    }
    
    // Initialize hardware watchdog
    esp_task_wdt_init(HW_WDT_TIMEOUT_S, true);
    esp_task_wdt_add(NULL);
    
    // Create tasks with proper stack sizes
    xTaskCreatePinnedToCore(watchdogTask, "Watchdog", 4096, NULL, 5, &watchdogTaskHandle, 0);
    xTaskCreatePinnedToCore(networkTask, "Network", 12288, NULL, 4, &networkTaskHandle, 0);
    xTaskCreatePinnedToCore(mainTask, "Main", 6144, NULL, 3, &mainTaskHandle, 1);
    xTaskCreatePinnedToCore(sensorTask, "Sensor", 6144, NULL, 2, &sensorTaskHandle, 1);
    
    vTaskDelete(NULL); // Delete setup task
}

void loop() {}

// =============== Hardware Initialization ===============
void initializeHardware() {
    // Initialize serial for modem with timeout
    Serial1.begin(115200, SERIAL_8N1, SIM_RX, SIM_TX);
    waitNonBlocking(1000);
    
    // Initialize power control pins
    pinMode(GSM_PWRKEY_PIN, OUTPUT);
    digitalWrite(GSM_PWRKEY_PIN, HIGH); // Default inactive
    
    // Initialize DS18B20
    ds18b20.begin();
    
    // Configure analog pins
    analogReadResolution(12);
    analogSetAttenuation(ADC_11db);
    
    Serial.println("\nHardware initialized");
    Serial.printf("Free heap: %d\n", ESP.getFreeHeap());
}

// =============== GSM Power Management ===============
void gsmPowerOn() {
    Serial.println("Powering on GSM module...");
    digitalWrite(GSM_PWRKEY_PIN, LOW);
    waitNonBlocking(GSM_POWER_ON_TIME);
    digitalWrite(GSM_PWRKEY_PIN, HIGH);
    waitNonBlocking(GSM_STARTUP_DELAY);
    lastModemRestart = millis();
    modemRestartCount++;
    Serial.println("GSM power on sequence complete");
}

void gsmPowerOff() {
    Serial.println("Powering off GSM module...");
    digitalWrite(GSM_PWRKEY_PIN, LOW);
    waitNonBlocking(GSM_POWER_OFF_TIME);
    digitalWrite(GSM_PWRKEY_PIN, HIGH);
    Serial.println("GSM power off sequence complete");
}

bool checkModemResponse() {
    for (int i = 0; i < 3; i++) {
        if (modem.testAT(2000)) {
            return true;
        }
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
    return false;
}

bool initializeModem() {
    Serial.println("Initializing modem...");
    
    for (int attempt = 1; attempt <= 3; attempt++) {
        Serial.printf("Attempt %d/3\n", attempt);
        hardRSTmodem();
        
        if (checkModemResponse()) {
            Serial.println("Modem responded to AT command");
            
            if (modem.restart()) {
                String modemInfo = modem.getModemInfo();
                Serial.print("Modem: ");
                Serial.println(modemInfo);
                return true;
            }
        }
        
        waitNonBlocking(5000);
    }
    
    Serial.println("Failed to initialize modem after 3 attempts");
    return false;
}

// =============== Network Functions ===============
bool connectToNetwork() {
    Serial.println("Connecting to network...");
    networkState = NETWORK_CONNECTING;
    
    if (!modem.waitForNetwork(300000)) { // 5 minute timeout
        Serial.println("Failed to connect to network");
        networkState = NETWORK_FAILED;
        return false;
    }
    
    if (!modem.isNetworkConnected()) {
        Serial.println("Network not connected");
        networkState = NETWORK_FAILED;
        return false;
    }
    
    Serial.print("Signal: ");
    Serial.println(modem.getSignalQuality());
    
    if (!modem.gprsConnect(apn, gprsUser, gprsPass)) {
        Serial.println("Failed to connect to GPRS");
        networkState = NETWORK_FAILED;
        return false;
    }
    
    Serial.print("IP: ");
    Serial.println(modem.getLocalIP());
    networkState = NETWORK_CONNECTED;
    return true;
}

bool connectToMQTT() {
    if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(2000))) {
        mqttClient.setServer(mqttBroker, mqttPort);
        
        String clientId = "ESP32-" + String(random(0xffff), HEX);
        bool connected = mqttClient.connect(
            clientId.c_str(), mqttUser, mqttPassword);
        
        if (connected) {
            Serial.println("MQTT connected");
            mqttConnected = true;
            lastSuccessfulMqtt = millis();
            blinkStatusLED(1);
        } else {
            Serial.println("MQTT connection failed");
            mqttConnected = false;
            blinkStatusLED(2);
        }
        
        xSemaphoreGive(mqttMutex);
        return connected;
    }
    return false;
}

// =============== Data Publishing ===============
// Modify publishSensorData to handle offline buffering
#define MAX_BUFFERED_MESSAGES 5

bool publishSensorData(const SensorData& data) {
    // 1. Pre-check conditions
    if (!mqttConnected) {
        Serial.println("[MQTT] Publish failed: Not connected");
        return false;
    }

    // 2. Prepare payload with size checking
    char payload[256]; // Buffer with safe margin
    int payloadLength = snprintf(payload, sizeof(payload),
        "{\"temp\":%.2f,\"a1\":%d,\"a2\":%d,\"a3\":%d,\"a4\":%d,"
        "\"batt\":%.2f,\"ts\":%lu,\"rssi\":%d}",
        data.temperature, data.analog1, data.analog2, 
        data.analog3, data.analog4, data.batteryVoltage, 
        data.timestamp, modem.getSignalQuality());

    // Validate payload before attempting publish
    if (payloadLength < 0 || payloadLength >= (int)sizeof(payload)) {
        Serial.println("[MQTT] Error: Payload generation failed");
        return false;
    }

    // 3. Thread-safe MQTT operations
    if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(2000)) == pdTRUE) {
        BaseType_t publishStatus = pdFAIL;
        
        // Verify connection state again under mutex
        if (mqttClient.connected()) {
            esp_task_wdt_reset(); // Feed watchdog
            
            // Attempt publish with timeout protection
            for (uint8_t attempt = 0; attempt < 3; attempt++) {
                if (mqttClient.publish(mqttTopic, payload)) {
                    publishStatus = pdPASS;
                    lastSuccessfulMqtt = millis();
                    digitalWrite(STATUS_LED_PIN, HIGH);
                    delay(50);
                    digitalWrite(STATUS_LED_PIN, LOW);
                    break;
                }
                delay(100 * (attempt + 1)); // Backoff delay
            }
        }

        xSemaphoreGive(mqttMutex);

        if (publishStatus == pdPASS) {
            Serial.println("[MQTT] Publish successful");
            return true;
        }
    } else {
        Serial.println("[MQTT] Error: Couldn't acquire mutex");
    }

    Serial.println("[MQTT] Publish failed after retries");
    return false;
}

bool sendSingleMessage(const SensorData& data) {
    char payload[250];
    snprintf(payload, sizeof(payload),
        "{\"temp\":%.2f,\"a1\":%d,\"a2\":%d,\"a3\":%d,\"a4\":%d,\"batt\":%.2f,\"ts\":%lu}",
        data.temperature, data.analog1, data.analog2, 
        data.analog3, data.analog4, data.batteryVoltage, data.timestamp);
    
    if (mqttClient.publish(mqttTopic, payload)) {
        lastSuccessfulMqtt = millis();
        blinkStatusLED(1);
        return true;
    }
    return false;
}

void publishHeartbeat(const SystemStatus& status) {
    if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(2000))) {
        if (mqttConnected) {
            char payload[250];
            snprintf(payload, sizeof(payload),
                "{\"heap\":%d,\"heap_min\":%d,\"uptime\":%d,\"net\":%d,\"mqtt\":%d,\"modem_r\":%d,\"voltage\":%.2f,\"rssi\":%d}",
                status.heapFree, status.heapMin, status.uptimeMinutes, 
                status.networkStatus, status.mqttStatus, status.modemRestarts, 
                status.supplyVoltage, status.rssi);
            
            if (mqttClient.publish(heartbeatTopic, payload)) {
                lastSuccessfulMqtt = millis();
            }
        }
        xSemaphoreGive(mqttMutex);
    }
}

void publishSystemEvent(const char* message) {
    if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(2000))) {
        if (mqttConnected) {
            char payload[200];
            snprintf(payload, sizeof(payload),
                "{\"event\":\"%s\",\"ts\":%lu,\"uptime\":%d}",
                message, millis()/1000, millis()/60000);
            
            mqttClient.publish(statusTopic, payload);
            lastSuccessfulMqtt = millis();
        }
        xSemaphoreGive(mqttMutex);
    }
}

// =============== Sensor Functions ===============
SensorData readSensors() {
    SensorData data;
    
    ds18b20.requestTemperatures();
    data.temperature = ds18b20.getTempCByIndex(0);
    
    data.analog1 = analogRead(ANALOG_PIN_1);
    data.analog2 = analogRead(ANALOG_PIN_2);
    data.analog3 = analogRead(ANALOG_PIN_3);
    data.analog4 = analogRead(ANALOG_PIN_4);
    
    data.batteryVoltage = readBatteryVoltage();
    data.timestamp = millis() / 1000;
    
    return data;
}

float readBatteryVoltage() {
    // Assuming voltage divider with 100k+100k resistors on ADC1_CH6 (GPIO34)
    const float voltageDividerRatio = 2.0;
    const float adcRefVoltage = 3.3;
    const int adcMax = 4095; // 12-bit ADC
    
    int raw = analogRead(ANALOG_PIN_1); // Or dedicated battery pin
    float voltage = (raw * adcRefVoltage / adcMax) * voltageDividerRatio;
    
    // Add low-pass filtering
    static float filteredVoltage = voltage;
    filteredVoltage = 0.9 * filteredVoltage + 0.1 * voltage;
    
    return 4.1;
    // return filteredVoltage;
}

SystemStatus getSystemStatus() {
    SystemStatus status;
    status.heapFree = ESP.getFreeHeap();
    status.heapMin = ESP.getMinFreeHeap();
    status.uptimeMinutes = millis() / 60000;
    status.networkStatus = networkState;
    status.mqttStatus = mqttConnected ? 1 : 0;
    status.modemRestarts = modemRestartCount;
    status.supplyVoltage = readBatteryVoltage();
    status.rssi = modem.getSignalQuality();
    return status;
}

// =============== System Functions ===============

void waitNonBlocking(unsigned long ms) {
    unsigned long start = millis();
    while (millis() - start < ms) {
        esp_task_wdt_reset();
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

void blinkStatusLED(int count) {
    for (int i = 0; i < count; i++) {
        digitalWrite(STATUS_LED_PIN, HIGH);
        waitNonBlocking(200);
        digitalWrite(STATUS_LED_PIN, LOW);
        if (i < count - 1)
            waitNonBlocking(200);
    }
}

void restartNetworkComponents() {
    Serial.println("Restarting network components...");
    
    if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(2000))) {
        if (mqttClient.connected()) {
            mqttClient.disconnect();
        }
        mqttConnected = false;
        xSemaphoreGive(mqttMutex);
    }
    
    modem.gprsDisconnect();
    networkState = NETWORK_DISCONNECTED;
    networkTaskHeartbeat = millis();
}

void emergencyPowerCycle() {
    Serial.println("Emergency power cycle...");
    blinkStatusLED(4);
    
    if (mqttMutex != NULL && xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(2000))) {
        if (mqttClient.connected()) {
            mqttClient.disconnect();
        }
        mqttConnected = false;
        xSemaphoreGive(mqttMutex);
    }
    
    modem.gprsDisconnect();
    gsmPowerOff();
    waitNonBlocking(3000);
    gsmPowerOn();
    
    networkState = NETWORK_DISCONNECTED;
    lastReconnectAttempt = millis() - NETWORK_RETRY_DELAY_MS;
}

void emergencyReset() {
    Serial.println("Emergency reset...");
    blinkStatusLED(5);
    
    if (mqttMutex != NULL && xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(2000))) {
        if (mqttClient.connected()) {
            mqttClient.disconnect();
        }
        xSemaphoreGive(mqttMutex);
    }
    
    if (modem.isNetworkConnected()) {
        modem.gprsDisconnect();
    }
    
    gsmPowerOff();
    delay(100);
    esp_restart();
}







//=========================================================================================
//*******************************    Network Task    *************************************/
//=========================================================================================
// =============== Task Implementations ===============
void networkTask(void *pvParameters) {
    Serial.println("[NET] Network task started");
    TickType_t xLastWakeTime = xTaskGetTickCount();
    const TickType_t xFrequency = pdMS_TO_TICKS(1000);
    
    // State tracking variables
    int networkRetryCount = 0;
    int gprsRetryCount = 0;
    const int MAX_NETWORK_RETRIES = 3;
    const int MAX_GPRS_RETRIES = 10;
    static unsigned long lastReconnectAttempt = millis() - NETWORK_RETRY_DELAY_MS; // Allow immediate first attempt

    for (;;) {
        // ===== 1. System Health Checks =====
        esp_task_wdt_reset(); // Critical for watchdog
        
        // Check modem responsiveness
        if (!modem.testAT(2000)) {
            Serial.println("[NET] Modem not responding - hard resetting");
            hardRSTmodem();
            vTaskDelay(pdMS_TO_TICKS(10000)); // Allow proper reboot time
            continue;
        }

        // Check battery voltage
        float voltage = readBatteryVoltage();
        if (voltage < GSM_MIN_OPERATING_VOLTAGE) {
            Serial.printf("[NET] Low voltage (%.2fV) - entering sleep\n", voltage);
            emergencySleep();
        }

        // Check modem temperature
        float modemTemp = modem.getTemperature();
        if (modemTemp > 70.0) {
            Serial.printf("[NET] Modem overheating (%.1f°C) - cooling down\n", modemTemp);
            gsmPowerOff();
            vTaskDelay(pdMS_TO_TICKS(30000)); // 30s cooldown
            gsmPowerOn();
            continue;
        }

        // ===== 2. Network State Assessment =====
        bool networkConnected = modem.isNetworkConnected();
        bool gprsConnected = modem.isGprsConnected();
        int signalQuality = modem.getSignalQuality();
        
        // Log current state for diagnostics
        Serial.printf("[NET] State: %s/%s, CSQ: %d, Retries: N%d/G%d\n",
            networkConnected ? "NET" : "noNET",
            gprsConnected ? "GPRS" : "noGPRS",
            signalQuality,
            networkRetryCount,
            gprsRetryCount);

        // ===== 3. State Handling =====
        // Case 1: Optimal state - process MQTT
        if (networkConnected && gprsConnected && signalQuality >= 10) {
            networkRetryCount = 0;
            gprsRetryCount = 0;
            
            processMQTT();
            vTaskDelayUntil(&xLastWakeTime, xFrequency);
            continue;
        }

        // Case 2: Network connected but GPRS/signal issues
        if (networkConnected && (!gprsConnected || signalQuality < 10)) {
            handleGprsRecovery(&gprsRetryCount, MAX_GPRS_RETRIES);
            vTaskDelayUntil(&xLastWakeTime, xFrequency);
            continue;
        }

        // Case 3: Network completely disconnected
        if (!networkConnected) {
            handleNetworkRecovery(&networkRetryCount, MAX_NETWORK_RETRIES);
        }

        vTaskDelayUntil(&xLastWakeTime, xFrequency);
    }
}

// ===== Helper Functions =====
void handleGprsRecovery(int* retryCount, int maxRetries) {
    unsigned long retryDelay = getRetryDelay(*retryCount);
    
    if (millis() - lastReconnectAttempt >= retryDelay) {
        Serial.println("[NET] Attempting GPRS recovery...");
        
        modem.gprsDisconnect();
        
        // Watchdog-friendly connection attempt
        unsigned long start = millis();
        bool success = false;
        while (millis() - start < 60000) { // 1min timeout
            esp_task_wdt_reset();
            if (modem.gprsConnect(apn, gprsUser, gprsPass)) {
                success = true;
                break;
            }
            vTaskDelay(pdMS_TO_TICKS(5000)); // 5s between attempts
        }

        if (success) {
            Serial.println("[NET] GPRS recovery successful");
            *retryCount = 0;
            connectToMQTT();
        } else {
            Serial.println("[NET] GPRS recovery failed");
            if (++(*retryCount) >= maxRetries) {
                Serial.println("[NET] Max retries reached - hard reset");
                hardRSTmodem();
                *retryCount = 0;
            }
        }
        lastReconnectAttempt = millis();
    }
}

void handleNetworkRecovery(int* retryCount, int maxRetries) {
    unsigned long retryDelay = getRetryDelay(*retryCount);
    
    if (millis() - lastReconnectAttempt >= retryDelay) {
        Serial.println("[NET] Attempting network recovery...");
        
        // Watchdog-friendly network wait
        unsigned long start = millis();
        bool success = false;
        while (millis() - start < 60000) { // 1min timeout
            esp_task_wdt_reset();
            if (modem.waitForNetwork(5000)) { // 5s chunks
                success = true;
                break;
            }
        }

        if (success) {
            Serial.println("[NET] Network recovery successful");
            *retryCount = 0;
            
            // Now attempt GPRS
            if (modem.gprsConnect(apn, gprsUser, gprsPass)) {
                connectToMQTT();
            }
        } else {
            Serial.println("[NET] Network recovery failed");
            if (++(*retryCount) >= maxRetries) {
                Serial.println("[NET] Max retries reached - hard reset");
                hardRSTmodem();
                *retryCount = 0;
            }
        }
        lastReconnectAttempt = millis();
    }
}

unsigned long getRetryDelay(int attempt) {
    // Exponential backoff: 1min, 2min, 4min (capped at 5min)
    return min(60000 * (1 << min(attempt, 2)), 300000);
}

void processMQTT() {
    if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(100))) {
        if (mqttConnected) {
            // Verify connection isn't stale
            if (!mqttClient.loop() || !mqttClient.connected()) {
                mqttConnected = false;
                Serial.println("[NET] MQTT connection lost");
            }
        } else {
            connectToMQTT();
        }
        xSemaphoreGive(mqttMutex);
    }
}

void emergencySleep() {
    Serial.println("[NET] Entering emergency sleep");
    publishSystemEvent("low_power_shutdown");
    
    // Deep sleep until battery recovers
    esp_sleep_enable_timer_wakeup(3600 * 1000000); // 1 hour
    esp_deep_sleep_start();
}

//=========================================================================================
//###############################   End Network Task    ###################################
//=========================================================================================









void mainTask(void *pvParameters) {
    Serial.println("Main task started");
    TickType_t xLastWakeTime = xTaskGetTickCount();
    const TickType_t xFrequency = pdMS_TO_TICKS(HEARTBEAT_INTERVAL_MS);
    
    for (;;) {
        mainTaskHeartbeat = millis();
        
        SystemStatus status = getSystemStatus();
        publishHeartbeat(status);
        
        Serial.printf("Uptime: %d min, Heap: %d, Net: %d, MQTT: %d, RSSI: %d\n",
            status.uptimeMinutes, status.heapFree, 
            status.networkStatus, status.mqttStatus, status.rssi);
        
        if (status.heapFree < MEMORY_CRITICAL_THRESHOLD) {
            Serial.println("Warning: Memory low!");
        }
        
        vTaskDelayUntil(&xLastWakeTime, xFrequency);
    }
}

void sensorTask(void *pvParameters) {
    Serial.println("Sensor task started [Robust Mode]");
    
    // Configuration - easily adjustable parameters
    const TickType_t xSensorReadInterval = pdMS_TO_TICKS(10000);    // 10 seconds
    const TickType_t xPublishInterval = pdMS_TO_TICKS(5 * 60 * 1000); // 5 minutes
    const uint8_t MAX_PUBLISH_RETRIES = 3;
    const uint16_t PUBLISH_RETRY_DELAY_MS = 1000;
    const size_t MAX_QUEUE_ITEMS = 5; // Matches queue size
    
    // State variables
    SensorData currentData = {0};
    bool newDataAvailable = false;
    uint32_t lastSuccessfulPublish = 0;
    uint8_t consecutiveReadErrors = 0;
    uint8_t consecutivePublishErrors = 0;

    // Initialize with current time to prevent immediate trigger
    TickType_t xLastSensorReadTime = xTaskGetTickCount();
    TickType_t xLastPublishTime = xTaskGetTickCount();
    
    for (;;) {
        // 1. Task Heartbeat Update
        sensorTaskHeartbeat = millis();
        
        // 2. Sensor Reading (10 second interval)
        if (xTaskGetTickCount() - xLastSensorReadTime >= xSensorReadInterval) {
            BaseType_t readStatus = pdFAIL;
            
            // Safe sensor reading with error handling
            for (uint8_t attempt = 0; attempt < 3; attempt++) {
                try {
                    currentData = readSensors();
                    readStatus = pdPASS;
                    consecutiveReadErrors = 0;
                    break;
                } catch (...) {
                    consecutiveReadErrors++;
                    vTaskDelay(pdMS_TO_TICKS(500 * (attempt + 1)));
                    if (consecutiveReadErrors >= 5) emergencyReset();
                }
            }
            
            if (readStatus == pdPASS) {
                newDataAvailable = true;
                Serial.printf("[Sensor] New reading - Temp: %.2fC\n", currentData.temperature);
            } else {
                Serial.println("[Sensor] Error: Failed to read sensors");
                // Use last good values if available
            }
            
            xLastSensorReadTime = xTaskGetTickCount();
        }

        // 3. Data Publishing Logic (5 minute interval or triggered)
        bool publishTriggered = (xTaskGetTickCount() - xLastPublishTime >= xPublishInterval) || 
                              (newDataAvailable && mqttConnected && uxQueueMessagesWaiting(sensorDataQueue) > 0);
        
        if (publishTriggered) {
            // 3.1 First process queued data if MQTT connected
            if (mqttConnected && uxQueueMessagesWaiting(sensorDataQueue) > 0) {
                Serial.printf("[Queue] Processing %d items in queue\n", uxQueueMessagesWaiting(sensorDataQueue));
                
                while (uxQueueMessagesWaiting(sensorDataQueue) > 0) {
                    SensorData queuedData;
                    if (xQueueReceive(sensorDataQueue, &queuedData, 10) == pdTRUE) {
                        bool published = false;
                        
                        for (uint8_t retry = 0; retry < MAX_PUBLISH_RETRIES; retry++) {
                            if (publishSensorData(queuedData)) {
                                published = true;
                                lastSuccessfulPublish = millis();
                                consecutivePublishErrors = 0;
                                break;
                            }
                            vTaskDelay(pdMS_TO_TICKS(PUBLISH_RETRY_DELAY_MS));
                        }
                        
                        if (!published) {
                            Serial.println("[Queue] Error: Failed to publish queued data");
                            consecutivePublishErrors++;
                            // Re-queue at the front if possible
                            xQueueSendToFront(sensorDataQueue, &queuedData, 0);
                            break; // Exit queue processing loop
                        }
                    }
                }
            }

            // 3.2 Handle current data if available
            if (newDataAvailable) {
                newDataAvailable = false;
                bool shouldQueue = true;
                
                if (mqttConnected) {
                    for (uint8_t retry = 0; retry < MAX_PUBLISH_RETRIES; retry++) {
                        if (publishSensorData(currentData)) {
                            lastSuccessfulPublish = millis();
                            consecutivePublishErrors = 0;
                            shouldQueue = false;
                            break;
                        }
                        vTaskDelay(pdMS_TO_TICKS(PUBLISH_RETRY_DELAY_MS));
                    }
                }
                
                // Queue if needed (with protection)
                if (shouldQueue) {
                    if (uxQueueSpacesAvailable(sensorDataQueue) > 0) {
                        xQueueSend(sensorDataQueue, &currentData, 0);
                    } else {
                        // Queue full - implement smart replacement
                        SensorData dummy;
                        xQueueReceive(sensorDataQueue, &dummy, 0);
                        xQueueSend(sensorDataQueue, &currentData, 0);
                        Serial.println("[Queue] Warning: Queue full - replaced oldest item");
                    }
                }
            }
            
            xLastPublishTime = xTaskGetTickCount();
        }

        // 4. Health Monitoring
        if (consecutivePublishErrors > 10) {
            Serial.println("[Health] Critical: Too many publish failures");
            emergencyReset();
        }
        
        // 5. Controlled Delay with Watchdog Feed
        esp_task_wdt_reset();
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

void watchdogTask(void *pvParameters) {
    Serial.println("Watchdog task started");
    TickType_t xLastWakeTime = xTaskGetTickCount();
    const TickType_t xFrequency = pdMS_TO_TICKS(WDT_CHECK_INTERVAL_MS);
    
    for (;;) {
        unsigned long now = millis();
        
        // Task monitoring
        if (now - networkTaskHeartbeat > TASK_WDT_TIMEOUT_MS) {
            Serial.println("Network task timeout!");
            emergencyPowerCycle();
            networkTaskHeartbeat = millis();
        }
        
        if (now - mainTaskHeartbeat > TASK_WDT_TIMEOUT_MS) {
            Serial.println("Main task timeout!");
            emergencyReset();
        }
        
        if (now - sensorTaskHeartbeat > TASK_WDT_TIMEOUT_MS) {
            Serial.println("Sensor task timeout!");
            emergencyReset();
        }
        
        // System health monitoring
        if (mqttConnected) {
            lastSuccessfulMqtt = now;
        } else if (now - lastSuccessfulMqtt > HEALTH_WDT_TIMEOUT_MS) {
            Serial.println("System health timeout!");
            emergencyReset();
        }
        
        // Memory monitoring
        if (ESP.getFreeHeap() < MEMORY_CRITICAL_THRESHOLD) {
            Serial.println("Critical memory low!");
            emergencyReset();
        }
        
        // Modem restart protection
        if (modemRestartCount > 5 && (now - lastModemRestart < 300000)) {
            Serial.println("Excessive modem restarts!");
            emergencyReset();
        }

        float batteryVoltage = readBatteryVoltage();
        if (batteryVoltage < GSM_MIN_OPERATING_VOLTAGE) {
            Serial.println("Critical battery level - entering sleep mode");
            publishSystemEvent("low_battery_shutdown");
            
            // Deep sleep until battery recovers or external wakeup
            esp_sleep_enable_timer_wakeup(3600 * 1000000); // 1 hour
            esp_deep_sleep_start();
        }

        // Monitor temperature
        // float modemTemp = modem.getTemperature();
        float modemTemp = 60;
        if (modemTemp > 70.0) { // Overheating protection
            Serial.println("Modem overheating - emergency shutdown");
            gsmPowerOff();
            delay(60000); // Cool down period
            gsmPowerOn();
        }
        
        // Feed hardware watchdog
        esp_task_wdt_reset();
        
        vTaskDelayUntil(&xLastWakeTime, xFrequency);
    }
}

void hardRSTmodem() {
  // Power cycle and hard reset modem
  Serial.println("Powering cycling and hard RST GSM module...");
    digitalWrite(GSM_PWRKEY_PIN, LOW);
    waitNonBlocking(GSM_POWER_ON_TIME);
    digitalWrite(GSM_PWRKEY_PIN, HIGH);
    waitNonBlocking(GSM_STARTUP_DELAY);
    Serial.println("GSM power on & hard RST sequence complete");
}